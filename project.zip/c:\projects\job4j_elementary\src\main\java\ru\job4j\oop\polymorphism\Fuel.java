package ru.job4j.oop.polymorphism;

public interface Fuel {
    void refill();
}
