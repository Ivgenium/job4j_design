package ru.job4j.generics;

import java.util.Date;

public class JavaProgrammer extends Programmer {
    public JavaProgrammer(String name, int age, Date birthday) {
        super(name, age, birthday);
    }
}
