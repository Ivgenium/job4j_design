package ru.job4j.comparator;

import java.util.Arrays;

public class ArraysSort {
    public static long[] sort(long[] data) {
        Arrays.sort(data);
        return data;
    }
}
