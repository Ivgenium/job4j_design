package ru.job4j.oop.polymorphism;

public interface Vehicle {

    void accelerate();

    void brake();

    void steer();

    void changeGear();

//    void test();
}
