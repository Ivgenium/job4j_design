package ru.job4j;

import com.sun.source.tree.Tree;

import java.util.*;

public class Main {
    public static void main(String[] args) {
//        System.out.println("Hello world");
        System.out.println("Воодушевленное настроение \uD83C\uDF1F");
        System.out.println("Счастливейший на свете \uD83D\uDE0E");
//        TreeSet<String> treeSet = new TreeSet<>();
//        treeSet.add(null);
//        TreeMap<String, String> treeMap = new TreeMap<>();
//        treeMap.put(null, null);
//        PriorityQueue<String> priorityQueue = new PriorityQueue<>();
//        priorityQueue.add(null);
//        Hashtable<String, String> hashtable = new Hashtable<>();
//        hashtable.put(null, null);
//        HashMap<String, String> hashMap = new HashMap<>();
//        hashMap.put(null, null);
//        hashMap.put("Nosov", "2");
//        hashMap.put("Zverev", "1");
//        HashSet<String> hashSet = new HashSet<>();
//        hashSet.add(null);
//        hashSet.add("Nosov");
//        ArrayDeque<String> arrayDeque = new ArrayDeque<>();
//        arrayDeque.add(null);
//        arrayDeque.add("Nosov");
//        Vector<String> vector = new Vector<>();
//        vector.add(null);
//        vector.add("Nosov");
//        List<Integer> list = new ArrayList<>();
//        List<?> list = new ArrayList<String>();
//        list.add("Long");
//        List list = new ArrayList();
//        list.add(1);
//        list.add("2");
//        System.out.println(list.size());
//        TreeSet treeSet = new TreeSet<>();
//        treeSet.add(1);
//        treeSet.add("2");
//        treeSet.add(3);
//        System.out.println(treeSet.size());
//        List<? super Object> list = new ArrayList<>();
//        list.add("Long");
    }
}