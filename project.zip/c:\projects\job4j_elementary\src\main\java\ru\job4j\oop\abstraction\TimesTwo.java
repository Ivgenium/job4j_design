package ru.job4j.oop.abstraction;

class TimesTwo extends Product {
    public TimesTwo(int n) {
        super(n);
    }
}
