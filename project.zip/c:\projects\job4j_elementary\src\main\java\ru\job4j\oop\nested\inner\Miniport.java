package ru.job4j.oop.nested.inner;

public class Miniport extends City.Airport {
    public Miniport(City city) {
        city.super();
    }
}
